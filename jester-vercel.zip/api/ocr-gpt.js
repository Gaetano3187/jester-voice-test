export default async function handler(req, res) {
  const { base64Image } = req.body;

  if (!base64Image) {
    return res.status(400).json({ error: 'Immagine mancante.' });
  }

  try {
    const openaiRes = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: 'gpt-4-vision-preview',
        messages: [
          {
            role: 'user',
            content: [
              { type: 'text', text: 'Estrai i prodotti da questo scontrino, solo elenco sintetico e chiaro.' },
              { type: 'image_url', image_url: { url: base64Image } }
            ]
          }
        ],
        max_tokens: 300
      })
    });

    const data = await openaiRes.json();
    res.status(200).json(data);
  } catch (error) {
    res.status(500).json({ error: 'Errore durante la chiamata a OpenAI', detail: error.message });
  }
}
